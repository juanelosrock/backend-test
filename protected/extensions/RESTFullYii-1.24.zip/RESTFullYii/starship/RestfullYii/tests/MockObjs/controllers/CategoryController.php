<?php
class CategoryController extends ERestBaseTestController
{
	//Mock Test Controller
}

