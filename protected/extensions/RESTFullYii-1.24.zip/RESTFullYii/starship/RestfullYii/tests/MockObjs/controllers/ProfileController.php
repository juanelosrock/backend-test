<?php
class ProfileController extends ERestBaseTestController
{
	//Mock Test Controller
}

